import React from 'react'

const Productspage = () => {
  return (
    <div>Products page</div>
  )
}

export default Productspage