import React from 'react'

const UsersPage = () => {
  return (
    <div>Users Page</div>
  )
}

export default UsersPage